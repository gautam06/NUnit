﻿using MockDemo2;
using NUnit.Framework;
using Rhino.Mocks;


namespace MockTest
{
    public class GreetingsTests
    {
        [Test]
        public void TestGreetActiveUserUsingMock()
        {
            // Arrange
            /*
            create mock [dummy object reference] of IUserService contract by using MockRepository.
            GenerateStub static method. 
            passed this instance to CompexGreeting constructor (constructor injection). 
            use this dummy object during IsActiveUser method execution.
            */

            IUserService service = MockRepository.GenerateStub<IUserService>();
            ComplexGreeting greet = new ComplexGreeting(service);
            string userName = "Gautam";
            service.Expect(x => x.IsActiveUSer(userName)).Return(true);

            /*
            expectations -> whenever IsActiveUser function gets 
            called with userName Gautam, it always returns True.
            */

            // Act
            /* because of mocked instance, IsActiveUSer function simply 
            return True as set in the expectations.
            */
            string output = greet.GreetActiveUser(userName);

            // Assert
            Assert.IsTrue(output.Equals("Greetings Gautam!"));
        }
    }
}