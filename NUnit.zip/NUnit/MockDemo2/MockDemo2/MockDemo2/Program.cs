﻿using System;

namespace MockDemo2
{
    public interface IUserService
    {
        bool IsActiveUSer(string userName);
    }

    public class UserService : IUserService
    {
        public bool IsActiveUSer(string userName)
        {
            // Retrieve user status from database or active directory. 
            // For demo purpose returning it true
            return true;
        }
    }

    public class ComplexGreeting
    {
        private IUserService service;

        public ComplexGreeting(IUserService userservice)
        {
            this.service = userservice;
        }

        public string GreetActiveUser(string userName)
        {
            var isActive = service.IsActiveUSer(userName);

            if (isActive)
                return string.Format("Greetings {0}!", userName);
            else
                throw new ArgumentException("Inactive user");
        }
    }

    public class Program
    {
        static void Main(string[] args)
        {
            UserService us = new UserService();

            ComplexGreeting cg = new ComplexGreeting(us);

            Console.WriteLine(cg.GreetActiveUser("gautam"));

            Console.ReadKey();
        }
    }
}
