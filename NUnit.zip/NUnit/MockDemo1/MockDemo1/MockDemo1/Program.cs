﻿using System;
using System.Security;
using NUnit.Framework;
using Moq;
//using Rhino.Mocks;

namespace MockDemo1
{
    interface IAverageJoeBankService
    {
        bool Authenticate(String userName, string password);
    }

    public class AverageJoeBankService : IAverageJoeBankService
    {
        public bool Authenticate(string userName, string password)
        {
            // This is just simulate the time taken for the web service to authenticate! 
            System.Threading.Thread.Sleep(5000);
            return true;
        }
    }

    public class User
    {
        public string UserName, Password;

    }

    
    public class AccountBalanceService
    {
        private IAverageJoeBankService _averageJoeService;

        public AccountBalanceService(IAverageJoeBankService averageJoeService)
        {
            _averageJoeService = averageJoeService;
        }

        public double GetAccountBalanceByUser(User user)
        {
            // the authenticate method below takes too much time! 
            bool isAuthenticated = _averageJoeService.Authenticate(user.UserName,
                user.Password);

            if (!isAuthenticated)
                throw new SecurityException("User is not authenticated");

            // access database using username and get the balance 

            return 100;
        }
    }
    

    public class x
    {
        private AccountBalanceService _accountBalanceService;
        private MockRepository _mocks;
        

        [SetUp]
        public void initialize()
        {
            _mocks = new MockRepository();
        }

        [Test]
        public void should_be_able_to_get_the_balance_successfully()
        {
            User user = new User();
            user.UserName = "JohnDoe";
            user.Password = "JohnPassword";

            var averageJoeService = _mocks.DynamicMock<IAverageJoeBankService>();

            _accountBalanceService = new AccountBalanceService(averageJoeService);

            using (_mocks.Record())
            {
                SetupResult.For(averageJoeService.Authenticate(null,
                    null)).IgnoreArguments().Return(true);

            }

            using (_mocks.Playback())
            {
                Assert.AreEqual(100, _accountBalanceService.GetAccountBalanceByUser(user));
            }
        }

    }


}
