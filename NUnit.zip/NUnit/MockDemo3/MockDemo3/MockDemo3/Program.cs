﻿using System;
using NUnit.Framework;
using Rhino.Mocks;

namespace MockDemo3
{

    public class Customer
    {
        public virtual void Order(int orderId)
        {
        }

        public virtual void Request(int requestId)
        {
            throw new Exception();
        }
    }

    public class CustomerTest
    {
        [Test]
        public void TestOrderAndRequestUsingStrictMock()
        {
            var mocks = MockRepository.GenerateStrictMock<Customer>();

            mocks.Expect(x => x.Order(100)).IgnoreArguments().Repeat.Times(2);

            mocks.Order(100);
            mocks.Order(200);

            // below method call will fail as Order method is getting 
            // called 3rd time, which is not expected
            // mocks.Order(300); 

            // this method call will fail as Request method is not setup 
            // in the expectation
            // mocks.Request(10); 

            mocks.VerifyAllExpectations();
        }

        [Test]
        public void TestOrderAndRequestUsingDynamicMock()
        {
            MockRepository mocks = new MockRepository();
            Customer cust = mocks.DynamicMock<Customer>();

            cust.Expect(x => x.Order(100)).IgnoreArguments().Repeat.Times(2);
            mocks.ReplayAll();

            cust.Order(100);
            cust.Order(200);

            // this method call won't fail even if its not set in the 
            // expectations because we have used DynamicMock method
            cust.Request(10);

            mocks.VerifyAll();
        }


        [Test]
        public void TestOrderAndRequestUsingPartialMock()
        {
            MockRepository mocks = new MockRepository();
            Customer cust = mocks.PartialMock<Customer>();

            cust.Expect(x => x.Order(100)).IgnoreArguments().Repeat.Times(2);
            mocks.ReplayAll();

            cust.Order(100);
            cust.Order(200);

            // this call won't fail even though not setup in the expectations
            cust.Order(300);

            // this call will fail as we have not setup 'Request&' method call
            //cust.Request(10); 

            mocks.VerifyAll();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
