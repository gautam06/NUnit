﻿using System;
using NUnit.Framework;
using NUnitConsoleApp1;

namespace ConsoleTest.Test
{
    /*
    [SetUp] 

    SetUp is generally used for initialization purposes.
    Any code that must be initialized or set prior to executing a 
    test is put in functions marked with this attribute. 
    As a consequence, it avoids the problem of code repetition in each test.*/

    [TestFixture]
    public class TestClass
    {
        [TestCase]
        public void AddTest()
        {
            MathsHelper helper = new MathsHelper();
            int result = helper.Add(20, 10);
            Assert.AreEqual(30, result);
        }

        [TestCase]
        public void SubtractTest()
        {
            MathsHelper helper = new MathsHelper();
            int result = helper.Subtract(20, 10);
            Assert.AreEqual(10, result);
        }

        [TestCase]
        public void MultiplicationTest()
        {
            MathsHelper helper = new MathsHelper();
            int result = helper.Multiply(6, 0);
            Assert.AreEqual(0,result);
        }

        [TestCase]
        public void DivisionTest()
        {
            MathsHelper helper = new MathsHelper();
            int result = helper.Division(6, 0);
            Assert.AreEqual(1, result);
        }

        [Test]
        [ExpectedException(typeof(DivideByZeroException))]
        public void DivisionTest2()
        {
            MathsHelper helper = new MathsHelper();
            int result = helper.Division(6, 0);
            //should not contain Assert Statement
            //Assert.AreEqual(1, result);
        }

        /*
        [Ignore]

        This is the attribute which is used for the code that 
        needs to be bypassed. */


        /* [TearDown]

        This is an attribute that acts the opposite of[SetUp]. 
        It means the code written with this attribute is executed 
        last(after passing other lines of code). 
        So, inside this closing is generally done, 
        i.e., closing of file system, database connection, etc.
        */


        //following test case for checking error in NUnit
        /* [TestCase]
         public void AddTest_Error()
         {
             MathsHelper helper = new MathsHelper();
             int result = helper.Add(20, 10);
             Assert.AreEqual(31, result);
         } */
    }
}
